from django.shortcuts import render, redirect
from django.urls import reverse
from django.contrib import messages
from django.utils import timezone
from .models import Reservation
from .forms import ReservationForm

def public_view(request):
    # Mostra apenas reservas futuras, ordenadas por horário
    reservations = Reservation.objects.filter(datetime__gte=timezone.now()).order_by('datetime')

    if request.method == 'POST':
        form = ReservationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Reserva criada com sucesso! Entraremos em contato para confirmar.')
            return redirect(reverse('reservas:public'))
    else:
        form = ReservationForm()

    context = {
        'form': form,
        'reservations': reservations,
    }
    return render(request, 'reservas/public.html', context)
