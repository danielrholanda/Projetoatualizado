from django import forms
from django.utils import timezone
from datetime import timedelta
from .models import Reservation
class ReservationForm(forms.ModelForm):
    datetime = forms.DateTimeField(
        widget=forms.DateTimeInput(attrs={'type': 'datetime-local'}),
        label='Data e hora'
    )
    class Meta:
        model = Reservation
        fields = ['name', 'phone', 'email', 'datetime', 'people', 'notes', 'status']
    def clean_datetime(self):
        dt = self.cleaned_data['datetime']
        now = timezone.now()
        # disallow past
        if dt < now:
            raise forms.ValidationError('Não é possível reservar em horários passados.')
        # max 30 days ahead
        if dt > now + timedelta(days=30):
            raise forms.ValidationError('Reservas só podem ser feitas com até 30 dias de antecedência.')
        # timezone naive handling: assume user provides local; fine for local dev
        # check day: Friday(4), Saturday(5), Sunday(6)
        weekday = dt.weekday()
        if weekday not in (4,5,6):
            raise forms.ValidationError('Reservas só permitidas de sexta a domingo.')
        # check hour between 18:00 and 23:00 (inclusive start, exclusive end at 23:00)
        hour = dt.hour
        minute = dt.minute
        if not (18 <= hour < 23):
            raise forms.ValidationError('Horário permitido: entre 18:00 e 23:00.')
        # enforce only one reservation per hour (same year/month/day/hour)
        start = dt.replace(minute=0, second=0, microsecond=0)
        end = start + timedelta(hours=1)
        # exclude self if updating - handled in view
        qs = Reservation.objects.filter(datetime__gte=start, datetime__lt=end)
        if self.instance.pk:
            qs = qs.exclude(pk=self.instance.pk)
        if qs.exists():
            raise forms.ValidationError('Já existe uma reserva nesse horário. Apenas uma por hora é permitida.')
        return dt
