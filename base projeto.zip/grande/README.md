Grande Mar Restaurante - Sistema de Reservas (Django + SQLite)

Como usar (resumo):
1. Crie e ative um virtualenv.
2. pip install -r requirements.txt
3. python manage.py migrate
4. python manage.py createsuperuser
5. python manage.py runserver
6. Abra http://127.0.0.1:8000/ (página pública)
   Admin: http://127.0.0.1:8000/admin/

Regras implementadas:
- Horário permitido: Sex/Sab/Dom entre 18:00 e 23:00
- Apenas 1 reserva por hora (bloqueio de duplicadas)
- Validações: não aceita datas passadas; máximo 30 dias à frente.