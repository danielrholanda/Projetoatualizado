from django.urls import path
from . import views

app_name = 'reservas'

urlpatterns = [
    path('', views.public_view, name='public'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('painel/', views.painel_reservas, name='painel'),
    path('confirmar/<int:pk>/', views.confirmar_reserva, name='confirmar'),
    path('cancelar/<int:pk>/', views.cancelar_reserva, name='cancelar'),
    path('excluir/<int:pk>/', views.excluir_reserva, name='excluir'),
]
