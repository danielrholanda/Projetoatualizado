from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from datetime import datetime, timedelta, time as dtime
from zoneinfo import ZoneInfo
from .models import Reservation
from .forms import ReservationForm

TIME_SLOTS = ['18:00','19:00','20:00','21:00','22:00','23:00']

# === Funções auxiliares ===
def get_next_30_valid_days():
    tz = ZoneInfo('America/Sao_Paulo')
    today = timezone.localtime(timezone.now(), tz).date()
    valid = []
    for i in range(0, 31):
        d = today + timedelta(days=i)
        if d.weekday() in (4, 5, 6):  # sexta, sábado, domingo
            free = False
            for t in TIME_SLOTS:
                hour, minute = map(int, t.split(':'))
                naive_dt = datetime.combine(d, dtime(hour, minute))
                aware_dt = timezone.make_aware(naive_dt, timezone=tz)
                start = aware_dt
                end = start + timedelta(hours=1)
                if not Reservation.objects.filter(datetime__gte=start, datetime__lt=end).exists():
                    free = True
                    break
            if free:
                valid.append((d.isoformat(), d.strftime('%a, %d/%m/%Y')))
    return valid


def get_available_times_for_date(d_iso):
    tz = ZoneInfo('America/Sao_Paulo')
    try:
        d = datetime.fromisoformat(d_iso).date()
    except:
        return []
    available = []
    for t in TIME_SLOTS:
        hour, minute = map(int, t.split(':'))
        naive_dt = datetime.combine(d, dtime(hour, minute))
        aware_dt = timezone.make_aware(naive_dt, timezone=tz)
        start = aware_dt
        end = start + timedelta(hours=1)
        if not Reservation.objects.filter(datetime__gte=start, datetime__lt=end).exists():
            available.append((t, t))
        else:
            available.append((t, f"{t} (Indisponível)"))
    return available


# === Página pública ===
def public_view(request):
    date_choices = get_next_30_valid_days()
    selected_date = request.POST.get('date') if request.method == 'POST' else (date_choices[0][0] if date_choices else None)
    time_choices = get_available_times_for_date(selected_date) if selected_date else []

    if request.method == 'POST':
        form = ReservationForm(request.POST, date_choices=date_choices, time_choices=time_choices)
        if form.is_valid():
            form.save()
            messages.success(request, 'Reserva criada com sucesso! Entraremos em contato para confirmar.')
            return redirect(reverse('reservas:public'))
        else:
            messages.error(request, 'Houve um erro, veja acima a solução.')
    else:
        form = ReservationForm(date_choices=date_choices, time_choices=time_choices)

    context = {
        'form': form,
        'date_choices': date_choices,
        'time_choices': time_choices,
    }
    return render(request, 'reservas/public.html', context)


# === Autenticação (login/logout) ===
def login_view(request):
    if request.user.is_authenticated:
        return redirect('reservas:painel')
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('reservas:painel')
        else:
            messages.error(request, 'Usuário ou senha incorretos.')
    return render(request, 'reservas/login.html')


def logout_view(request):
    logout(request)
    return redirect('reservas:login')


# === Painel administrativo protegido ===
@login_required
def painel_reservas(request):
    reservas = Reservation.objects.all().order_by('datetime')

    # Filtro de data
    data_filtro = request.GET.get('data')
    if data_filtro:
        try:
            data_dt = datetime.strptime(data_filtro, "%Y-%m-%d").date()
            reservas = reservas.filter(datetime__date=data_dt)
        except ValueError:
            pass

    # Ordena pelas mais próximas
    reservas = reservas.order_by('datetime')

    return render(request, 'reservas/painel.html', {'reservas': reservas})



@login_required
def confirmar_reserva(request, pk):
    reserva = get_object_or_404(Reservation, pk=pk)
    if reserva.status != 'confirmed':
        reserva.status = 'confirmed'
        reserva.save()
        messages.success(request, f'Reserva de {reserva.name} confirmada.')
    return redirect('reservas:painel')


@login_required
def cancelar_reserva(request, pk):
    reserva = get_object_or_404(Reservation, pk=pk)
    if reserva.status != 'canceled':
        reserva.status = 'canceled'
        reserva.save()
        messages.warning(request, f'Reserva de {reserva.name} cancelada.')
    return redirect('reservas:painel')


@login_required
def excluir_reserva(request, pk):
    reserva = get_object_or_404(Reservation, pk=pk)

    if request.method == "POST":
        nome = reserva.name
        reserva.delete()
        messages.info(request, f"Reserva de {nome} excluída.")
        return redirect('reservas:painel')

    # Se for GET, exibe uma página pedindo confirmação
    return render(request, 'reservas/confirmar_exclusao.html', {'reserva': reserva})
