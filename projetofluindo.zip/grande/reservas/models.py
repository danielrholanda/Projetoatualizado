from django.db import models
class Reservation(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pendente'),
        ('confirmed', 'Confirmada'),
        ('canceled', 'Cancelada'),
    ]
    name = models.CharField('Nome', max_length=100)
    phone = models.CharField('Telefone', max_length=30)
    email = models.EmailField('Email', blank=True)
    datetime = models.DateTimeField('Data e hora')
    people = models.PositiveIntegerField('Pessoas', default=2)
    notes = models.TextField('Observações', blank=True)
    status = models.CharField('Status', max_length=10, choices=STATUS_CHOICES, default='pending')
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering = ['-datetime']
    def __str__(self):
        return f"{self.name} — {self.datetime.strftime('%Y-%m-%d %H:%M')} ({self.people})"
