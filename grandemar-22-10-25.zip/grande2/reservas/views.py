from django.shortcuts import render, redirect
from django.urls import reverse
from django.contrib import messages
from django.utils import timezone
from datetime import datetime, timedelta, date, time as dtime
from zoneinfo import ZoneInfo
from .models import Reservation
from .forms import ReservationForm

TIME_SLOTS = ['18:00','19:00','20:00','21:00','22:00','23:00']

def get_next_30_valid_days():
    tz = ZoneInfo('America/Sao_Paulo')
    today = timezone.localtime(timezone.now(), tz).date()
    valid = []
    for i in range(0, 31):
        d = today + timedelta(days=i)
        if d.weekday() in (4,5,6):  # Fri, Sat, Sun
            free = False
            for t in TIME_SLOTS:
                hour, minute = map(int, t.split(':'))
                naive_dt = datetime.combine(d, dtime(hour, minute))
                aware_dt = timezone.make_aware(naive_dt, timezone=tz)
                start = aware_dt
                end = start + timedelta(hours=1)
                if not Reservation.objects.filter(datetime__gte=start, datetime__lt=end).exists():
                    free = True
                    break
            if free:
                valid.append((d.isoformat(), d.strftime('%a, %d/%m/%Y')))
    return valid

def get_available_times_for_date(d_iso):
    tz = ZoneInfo('America/Sao_Paulo')
    try:
        d = datetime.fromisoformat(d_iso).date()
    except:
        return []
    available = []
    for t in TIME_SLOTS:
        hour, minute = map(int, t.split(':'))
        naive_dt = datetime.combine(d, dtime(hour, minute))
        aware_dt = timezone.make_aware(naive_dt, timezone=tz)
        start = aware_dt
        end = start + timedelta(hours=1)
        if not Reservation.objects.filter(datetime__gte=start, datetime__lt=end).exists():
            available.append((t, t))
    return available

def public_view(request):
    date_choices = get_next_30_valid_days()
    selected_date = request.POST.get('date') if request.method=='POST' else (date_choices[0][0] if date_choices else None)
    time_choices = get_available_times_for_date(selected_date) if selected_date else []

    if request.method == 'POST':
        form = ReservationForm(request.POST, date_choices=date_choices)
        form.fields['time'].choices = time_choices
        if form.is_valid():
            form.save()
            messages.success(request, 'Reserva criada com sucesso! Entraremos em contato para confirmar.')
            return redirect(reverse('reservas:public'))
        else:
            date_choices = get_next_30_valid_days()
    else:
        form = ReservationForm(date_choices=date_choices)
    reservations = Reservation.objects.filter(datetime__gte=timezone.now()).order_by('datetime')
    context = {
        'form': form,
        'reservations': reservations,
        'date_choices': date_choices,
        'time_choices': time_choices,
    }
    return render(request, 'reservas/public.html', context)
