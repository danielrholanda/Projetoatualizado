from django import forms
from django.utils import timezone
from datetime import datetime, time as dtime, timedelta
from .models import Reservation
from zoneinfo import ZoneInfo

TIME_CHOICES = [
    ('18:00', '18:00'),
    ('19:00', '19:00'),
    ('20:00', '20:00'),
    ('21:00', '21:00'),
    ('22:00', '22:00'),
    ('23:00', '23:00'),
]

class ReservationForm(forms.ModelForm):
    date = forms.ChoiceField(label='Data da reserva', choices=[], required=True)
    time = forms.ChoiceField(label='Horário', choices=TIME_CHOICES, required=True)

    class Meta:
        model = Reservation
        fields = ['name', 'phone', 'email', 'date', 'time', 'people', 'notes']

    def __init__(self, *args, **kwargs):
        date_choices = kwargs.pop('date_choices', None)
        super().__init__(*args, **kwargs)
        if date_choices is not None:
            self.fields['date'].choices = date_choices

    def clean(self):
        cleaned = super().clean()
        d = cleaned.get('date')
        t = cleaned.get('time')
        if not d or not t:
            return cleaned
        try:
            date_obj = datetime.fromisoformat(d).date()
        except Exception as e:
            raise forms.ValidationError('Data inválida.')

        hour, minute = map(int, t.split(':'))
        naive_dt = datetime.combine(date_obj, dtime(hour, minute))
        tz = ZoneInfo('America/Sao_Paulo')
        aware_dt = timezone.make_aware(naive_dt, timezone=tz)
        now = timezone.now()
        if aware_dt < now:
            raise forms.ValidationError('Não é possível reservar em horários passados.')
        if aware_dt > now + timedelta(days=30):
            raise forms.ValidationError('Reservas só podem ser feitas com até 30 dias de antecedência.')
        if date_obj.weekday() not in (4,5,6):
            raise forms.ValidationError('Reservas só permitidas de sexta a domingo.')
        start = aware_dt
        end = start + timedelta(hours=1)
        qs = Reservation.objects.filter(datetime__gte=start, datetime__lt=end)
        if self.instance.pk:
            qs = qs.exclude(pk=self.instance.pk)
        if qs.exists():
            raise forms.ValidationError('Esse horário já está reservado. Escolha outro.')
        self.cleaned_data['datetime'] = aware_dt
        return cleaned

    def save(self, commit=True):
        self.instance.datetime = self.cleaned_data.get('datetime')
        return super().save(commit=commit)
