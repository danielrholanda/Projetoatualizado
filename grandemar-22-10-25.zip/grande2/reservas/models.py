from django.db import models
from django.utils import timezone
import pytz

class Reservation(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pendente'),
        ('confirmed', 'Confirmada'),
        ('canceled', 'Cancelada'),
    ]
    name = models.CharField('Nome', max_length=100)
    phone = models.CharField('Telefone', max_length=30)
    email = models.EmailField('Email', blank=True)
    datetime = models.DateTimeField('Data e hora')
    people = models.PositiveIntegerField('Pessoas', default=2)
    notes = models.TextField('Observações', blank=True)
    status = models.CharField('Status', max_length=10, choices=STATUS_CHOICES, default='pending')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-datetime']
        verbose_name = 'Reserva'
        verbose_name_plural = 'Reservas'

    def __str__(self):
        local_tz = pytz.timezone('America/Sao_Paulo')
        local_time = timezone.localtime(self.datetime, local_tz)
        return f"{self.name} — {local_time.strftime('%d/%m/%Y %H:%M')} ({self.people} pessoas)"

    @property
    def local_datetime(self):
        """Retorna a data/hora da reserva no fuso de São Paulo."""
        local_tz = pytz.timezone('America/Sao_Paulo')
        return timezone.localtime(self.datetime, local_tz)
