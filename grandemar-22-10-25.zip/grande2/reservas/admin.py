from django.contrib import admin
from .models import Reservation

@admin.register(Reservation)
class ReservationAdmin(admin.ModelAdmin):
    list_display = ('name', 'local_datetime_display', 'people', 'status')
    list_filter = ('status',)
    search_fields = ('name', 'phone', 'email')
    readonly_fields = ('created_at',)

    def local_datetime_display(self, obj):
        return obj.local_datetime.strftime('%d/%m/%Y %H:%M')
    local_datetime_display.short_description = 'Horário (local)'
